# Kiến Thức Dịch Vụ TechMax AI

## Tổng quan

TechMax AI là nền tảng hỗ trợ doanh nghiệp, shop online, cá nhân kinh doanh và đội sale tự động hóa tư vấn, chăm sóc khách hàng, quản lý hội thoại và thực hiện một số tác vụ marketing/vận hành trên các kênh như website, Zalo, Facebook/Fanpage.

Website chính: https://techmaxai.store

TechMax AI không chỉ là chatbot. Hệ thống gồm nhiều phần:
- Chatbot AI.
- Phòng đào tạo bot.
- Quản lý hội thoại.
- Kết nối Zalo.
- Kết nối Facebook/Fanpage.
- Auto Facebook.
- Quản lý proxy.
- Nạp tiền và hóa đơn.
- Gói dịch vụ.
- Trang quản trị admin.

## 1. Chatbot AI

Chatbot AI là tính năng trọng tâm của TechMax AI.

Bot AI có thể:
- Trả lời câu hỏi của khách.
- Giới thiệu sản phẩm/dịch vụ.
- Hỏi nhu cầu.
- Tư vấn gói phù hợp.
- Giải thích chính sách.
- Hướng dẫn khách thực hiện các bước mua hàng/đăng ký.
- Giảm tải cho nhân viên chăm sóc khách hàng.

Dữ liệu đào tạo có thể gồm:
- Thông tin doanh nghiệp.
- Mô tả sản phẩm/dịch vụ.
- Bảng giá.
- Chính sách bảo hành, đổi trả, hoàn tiền.
- Quy trình tư vấn.
- Câu hỏi thường gặp.
- Quy định bot được và không được trả lời.
- Mẫu kịch bản bán hàng.

Bot AI phù hợp với:
- Shop online.
- Đơn vị dịch vụ.
- Trung tâm đào tạo.
- Agency marketing.
- Doanh nghiệp có nhiều khách nhắn tin.
- Đội sale muốn tiết kiệm thời gian lặp lại.

Lợi ích:
- Phản hồi nhanh hơn.
- Không bỏ sót khách.
- Giữ thông điệp tư vấn đồng nhất.
- Hỗ trợ nhân viên tư vấn.
- Có thể đào tạo theo phong cách riêng của doanh nghiệp.

## 2. Phòng đào tạo bot

Phòng đào tạo là nơi người dùng nhập dữ liệu cho bot học.

Nên hướng dẫn khách chuẩn bị:
- Mô tả tính cách bot.
- Mô tả doanh nghiệp.
- Danh sách dịch vụ/sản phẩm.
- Lợi ích từng dịch vụ.
- Đối tượng khách hàng phù hợp.
- Kịch bản hỏi đáp.
- Quy định không được trả lời sai.
- Hướng dẫn xử lý khi khách muốn mua.

Nếu khách nói “tôi không biết nhập gì vào đào tạo”, hãy đề xuất:
- Bắt đầu từ thông tin doanh nghiệp.
- Thêm danh sách dịch vụ.
- Thêm bảng FAQ.
- Thêm quy trình tư vấn.
- Thêm các câu mẫu khách hay hỏi.

## 3. Quản lý hội thoại

Hệ thống có phần quản lý hội thoại để theo dõi tương tác với khách.

Giá trị tư vấn:
- Tập trung hội thoại vào một nơi.
- Giảm bỏ sót tin nhắn.
- Dễ quản lý lịch sử trao đổi.
- Hỗ trợ nhân viên hoặc bot tiếp tục chăm sóc khách.

Nên tư vấn khi khách:
- Có nhiều khách nhắn tin mỗi ngày.
- Đang bán hàng đa kênh.
- Muốn chăm sóc lại khách cũ.
- Muốn đội sale quản lý hội thoại gọn hơn.

## 4. Zalo

TechMax AI hỗ trợ kết nối tài khoản Zalo bằng QR.

Khả năng:
- Tạo mã QR đăng nhập Zalo.
- Chọn proxy trước khi tạo QR nếu cần.
- Lưu dữ liệu tài khoản Zalo theo tài khoản TechMax sau khi quét QR thành công.
- Quản lý danh sách tài khoản Zalo.
- Bật/tắt bot AI cho tài khoản Zalo.

Khi tư vấn:
- Nếu khách bán hàng qua Zalo, đề xuất kết nối Zalo với bot AI.
- Nếu khách bị lỗi đăng nhập hoặc proxy, hướng dẫn kiểm tra proxy và quét lại QR.
- Không yêu cầu khách gửi mật khẩu Zalo.

Cần nói rõ:
- Đăng nhập Zalo phụ thuộc vào nền tảng Zalo và tình trạng tài khoản.
- Nếu Zalo thay đổi cơ chế đăng nhập, có thể cần cập nhật hệ thống.

## 5. Facebook/Fanpage

TechMax AI có các phần liên quan Facebook/Fanpage.

Giá trị:
- Hỗ trợ quản lý kênh Facebook/Fanpage.
- Hỗ trợ chăm sóc khách trên các kênh có liên quan Facebook.
- Có thể kết hợp với bot AI để trả lời/tư vấn tốt hơn.

Khi tư vấn:
- Nếu khách có Fanpage bán hàng, đề xuất dùng bot AI và quản lý hội thoại.
- Nếu khách hỏi Facebook Login/OAuth, nói đây là cấu hình kết nối và cần thiết lập đúng trên Meta Developer.
- Nếu khách gặp lỗi OAuth, chuyển nhân viên kỹ thuật.

## 6. Auto Facebook

Auto Facebook là công cụ hỗ trợ tự động hóa một số tác vụ trên Facebook.

Tính năng:
- Lưu tài khoản bằng cookie.
- Chọn tài khoản cần chạy.
- Chạy reaction.
- Chạy comment.
- Join group.
- Comment group.
- Đăng bài group.
- Theo dõi nhật ký hoạt động realtime.
- Dùng proxy theo từng tài khoản.
- Kiểm tra proxy trước khi chạy.
- Hiển thị IP Chrome, IP proxy, vị trí proxy, ping và trạng thái xác nhận proxy.
- Hỗ trợ headless Chrome.
- Hỗ trợ chế độ máy yếu giảm tải Chrome.
- Giới hạn luồng toàn hệ thống theo cấu hình admin.

Nên tư vấn Auto Facebook khi khách:
- Muốn hỗ trợ marketing Facebook.
- Muốn tự động hóa một số thao tác lặp lại.
- Có nhiều tài khoản Facebook cần quản lý tác vụ.
- Cần sử dụng proxy riêng cho từng tài khoản.

Lưu ý phải nói rõ:
- Auto Facebook phụ thuộc vào Facebook, cookie, proxy và tình trạng tài khoản.
- Không cam kết tránh checkpoint/khóa tài khoản.
- Không khuyến khích spam, lừa đảo, mạo danh.
- Khách phải tự chịu trách nhiệm về cách sử dụng tài khoản và nội dung.

## 7. Proxy

Proxy được dùng để gán IP riêng cho Zalo/Auto Facebook.

Tính năng proxy:
- Thêm proxy.
- Lưu proxy.
- Kiểm tra proxy live.
- Chọn proxy khi đăng nhập Zalo.
- Gán proxy cho tài khoản Facebook Auto.
- Kiểm tra IP Chrome có trùng IP proxy hay không.
- Hiển thị vị trí proxy.

Khi tư vấn:
- Nếu khách chạy nhiều tài khoản, proxy giúp tách môi trường IP.
- Nếu proxy lỗi, khách cần kiểm tra lại định dạng, tài khoản/mật khẩu proxy, ping, IP exit.

Định dạng proxy có thể gặp:
- `host:port`
- `host:port:user:pass`
- `http://host:port:user:pass`
- `https://host:port:user:pass`

Không nên nói proxy đảm bảo an toàn tuyệt đối. Proxy chỉ là một yếu tố kỹ thuật.

## 8. Nạp tiền và hóa đơn

Người dùng có thể nạp tiền bằng cách tạo hóa đơn.

Quy trình:
1. Đăng nhập website.
2. Vào trang Nạp tiền.
3. Nhập số tiền.
4. Tạo hóa đơn.
5. Chuyển khoản đúng số tiền và đúng nội dung.
6. Kiểm tra trạng thái tại mục Hóa đơn.

Trạng thái hóa đơn:
- Chờ thanh toán.
- Đã thanh toán.
- Đã hết hạn.
- Đã hủy.

Lưu ý:
- Hóa đơn có thời hạn thanh toán.
- Quá hạn thì nên tạo hóa đơn mới.
- Bot không được xác nhận khách đã thanh toán.
- Nếu khách đã chuyển khoản nhưng chưa ghi nhận, hướng dẫn liên hệ nhân viên hỗ trợ.

## 9. Gói dịch vụ

Một số tính năng cần gói dịch vụ còn hạn.

Khi gói hết hạn:
- Một số tính năng có thể bị hạn chế.
- Khách cần mua mới hoặc gia hạn gói.

Tư vấn:
- Nếu khách mới, hướng dẫn đăng ký, nạp tiền và xem trang gói dịch vụ.
- Nếu khách đang bị hạn chế tính năng, hỏi xem gói đã hết hạn chưa.

Không được bịa giá gói nếu không có bảng giá trong dữ liệu.

## 10. Admin và quản trị

Admin có thể quản lý:
- Người dùng.
- Gói dịch vụ.
- Hóa đơn.
- Cài đặt ngân hàng.
- Auth/OAuth.
- Zalo accounts.
- Facebook Auto.
- Proxy.
- Logs.
- Thông báo.
- Hợp đồng.
- Website settings.

Bot bán hàng chỉ nên giới thiệu tổng quan. Nếu khách hỏi thao tác admin chi tiết, nên nói cần tài khoản admin và có thể chuyển nhân viên kỹ thuật.
