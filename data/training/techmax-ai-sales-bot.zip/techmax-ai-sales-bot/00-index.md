# TechMax AI Sales Bot Training

Website: https://techmaxai.store

Mục đích bộ dữ liệu này:
- Đào tạo BOT AI tư vấn bán hàng cho toàn bộ dịch vụ của TechMax AI.
- Dùng cho phòng đào tạo của project, không cần kết nối API.
- Bot có nhiệm vụ giới thiệu dịch vụ, hỏi nhu cầu, tư vấn gói giải pháp, hướng dẫn khách đăng ký, nạp tiền, tạo hóa đơn và sử dụng tính năng.

Danh sách file:

1. `01-thong-tin-co-ban.md`
   - Tên bot, vai trò, tính cách, phong cách trả lời, giới hạn nhiệm vụ.

2. `02-kien-thuc-dich-vu.md`
   - Kiến thức chi tiết về các dịch vụ trong project: Chatbot AI, Zalo, Facebook/Fanpage, Auto Facebook, Proxy, hóa đơn, gói dịch vụ, admin.

3. `03-ky-nang-tu-van.md`
   - Quy trình tư vấn, cách hỏi nhu cầu, cách phân loại khách, cách chốt bước tiếp theo.

4. `04-kich-ban-hoi-thoai.md`
   - Nhiều mẫu hội thoại bán hàng theo tình huống thực tế.

5. `05-faq.md`
   - Câu hỏi thường gặp và câu trả lời mẫu.

6. `06-quy-dinh-hoat-dong.md`
   - Những điều bot được nói, không được nói, quy tắc thanh toán, bảo mật, Facebook/Zalo.

7. `07-tai-lieu-train-chi-tiet.md`
   - Bản train chi tiết, có thể copy vào mục “Train chi tiết” của phòng đào tạo.

8. `08-du-lieu-chong-tra-loi-sai.md`
   - Các câu trả lời an toàn khi bot không biết, khi khách hỏi giá, thanh toán, lỗi kỹ thuật, cam kết kết quả.

9. `09-checklist-nhap-du-lieu.md`
   - Checklist để nhập vào phòng đào tạo.

Gợi ý sử dụng:
- Nếu phòng đào tạo có mục “Thông tin cơ bản”: dùng file `01-thong-tin-co-ban.md`.
- Nếu có mục “Train chi tiết”: ưu tiên copy file `07-tai-lieu-train-chi-tiet.md`, sau đó bổ sung thêm `02`, `03`, `04`, `05`, `06`, `08`.
- Nếu bot trả lời chưa đúng phong cách, bổ sung file `03` và `06`.
