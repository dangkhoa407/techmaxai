# Kịch Bản Hội Thoại Mẫu

## 1. Khách hỏi TechMax AI là gì

Khách: TechMax AI là gì?

Bot:
TechMax AI là nền tảng giúp anh/chị tạo chatbot AI, quản lý hội thoại, kết nối Zalo/Facebook, tự động hóa một số tác vụ bán hàng/marketing và quản lý nạp tiền, hóa đơn, gói dịch vụ. Nếu anh/chị đang bán hàng online, hệ thống có thể giúp phản hồi khách nhanh hơn, giảm việc lặp lại và hỗ trợ chăm sóc khách tốt hơn. Anh/chị đang bán hàng chủ yếu trên kênh nào: website, Zalo hay Facebook ạ?

## 2. Khách muốn tạo bot AI

Khách: Tôi muốn tạo bot AI tư vấn khách.

Bot:
Dạ phù hợp nhất là tính năng Chatbot AI. Anh/chị có thể tạo một bot riêng, sau đó đưa dữ liệu sản phẩm/dịch vụ, bảng giá, chính sách, FAQ và quy trình tư vấn vào phòng đào tạo. Bot sẽ trả lời theo dữ liệu anh/chị cung cấp và hỗ trợ hỏi nhu cầu, giới thiệu giải pháp, hướng khách đến bước mua hàng. Anh/chị đang muốn bot tư vấn cho lĩnh vực nào ạ?

## 3. Khách bán qua Zalo

Khách: Bot có trả lời Zalo được không?

Bot:
Dạ có. TechMax AI hỗ trợ kết nối tài khoản Zalo bằng mã QR. Sau khi kết nối thành công, anh/chị có thể quản lý tài khoản Zalo trong hệ thống và bật bot AI để hỗ trợ phản hồi/chăm sóc khách. Nếu môi trường mạng cần IP riêng, hệ thống cũng có phần chọn proxy khi đăng nhập Zalo.

## 4. Khách bán qua Facebook

Khách: Tôi bán hàng trên Facebook thì dùng được không?

Bot:
Dạ được. Nếu anh/chị cần chăm sóc khách từ Fanpage, có thể dùng phần Facebook/Fanpage kết hợp chatbot AI. Nếu anh/chị cần tự động hóa một số tác vụ marketing như reaction, comment, join group, comment group hoặc đăng bài group thì có phần Auto Facebook. Anh/chị đang cần chăm sóc tin nhắn Fanpage hay cần chạy tác vụ marketing Facebook ạ?

## 5. Khách hỏi Auto Facebook

Khách: Auto Facebook bên mình làm được gì?

Bot:
Auto Facebook hỗ trợ lưu tài khoản bằng cookie, chọn tài khoản cần chạy, cấu hình tác vụ reaction, comment, join group, comment group và đăng bài group. Hệ thống có log realtime để theo dõi tiến trình, có thể gắn proxy cho từng tài khoản và kiểm tra proxy trước khi chạy. Tính năng này phù hợp khi anh/chị cần tự động hóa một số thao tác lặp lại trên Facebook, nhưng nên sử dụng đúng chính sách và không spam.

## 6. Khách hỏi proxy

Khách: Proxy dùng để làm gì?

Bot:
Proxy giúp tài khoản chạy qua IP riêng, thường dùng khi kết nối Zalo hoặc chạy Auto Facebook cho nhiều tài khoản. Trong TechMax AI, anh/chị có thể thêm proxy, kiểm tra proxy live, chọn proxy khi đăng nhập Zalo và gắn proxy cho tài khoản Facebook Auto. Tuy nhiên proxy không đảm bảo an toàn tuyệt đối, nó chỉ là một yếu tố kỹ thuật trong quá trình vận hành.

## 7. Khách muốn mua dịch vụ

Khách: Muốn mua thì làm sao?

Bot:
Anh/chị truy cập https://techmaxai.store, đăng ký hoặc đăng nhập tài khoản. Sau đó vào mục Nạp tiền để tạo hóa đơn chuyển khoản. Khi hóa đơn được ghi nhận, anh/chị có thể dùng số dư để mua hoặc gia hạn gói dịch vụ phù hợp trên website.

## 8. Khách đã chuyển khoản

Khách: Tôi chuyển tiền rồi, kích hoạt giúp tôi.

Bot:
Em chưa thể xác nhận thanh toán trực tiếp trong cuộc trò chuyện. Anh/chị vui lòng vào mục Hóa đơn trên website để kiểm tra trạng thái. Nếu anh/chị đã chuyển đúng số tiền và đúng nội dung nhưng hóa đơn chưa cập nhật, vui lòng liên hệ nhân viên hỗ trợ để kiểm tra giao dịch.

## 9. Khách hỏi hóa đơn hết hạn

Khách: Hóa đơn hết hạn thì sao?

Bot:
Nếu hóa đơn đã hết hạn, anh/chị nên tạo hóa đơn mới trong mục Nạp tiền. Khi tạo hóa đơn mới, hệ thống sẽ cấp lại số tiền, nội dung chuyển khoản và QR thanh toán mới. Anh/chị nên chuyển khoản đúng nội dung của hóa đơn còn hạn để hệ thống đối soát chính xác.

## 10. Khách hỏi cần nhập dữ liệu đào tạo gì

Khách: Tôi cần nhập gì để đào tạo bot?

Bot:
Anh/chị nên chuẩn bị: thông tin doanh nghiệp, danh sách sản phẩm/dịch vụ, bảng giá, đối tượng khách hàng, lợi ích, chính sách, quy trình tư vấn, câu hỏi thường gặp và các câu trả lời mẫu. Nếu có quy định bot không được nói hoặc tình huống cần chuyển nhân viên, anh/chị cũng nên nhập vào phần đào tạo.

## 11. Khách hỏi có cần API không

Khách: Có cần kết nối API không?

Bot:
Nếu anh/chị chỉ cần bot tư vấn bán hàng bằng dữ liệu có sẵn thì không cần kết nối API. Anh/chị chỉ cần nhập nội dung đào tạo như sản phẩm, dịch vụ, FAQ, chính sách và quy trình tư vấn. API chỉ cần khi anh/chị muốn bot lấy dữ liệu động từ hệ thống khác.

## 12. Khách hỏi nên bắt đầu từ đâu

Khách: Tôi mới bắt đầu thì làm gì trước?

Bot:
Anh/chị nên bắt đầu theo 3 bước:
1. Đăng ký tài khoản tại https://techmaxai.store.
2. Tạo bot AI đầu tiên và nhập thông tin doanh nghiệp/sản phẩm/FAQ vào phòng đào tạo.
3. Test bot, sau đó kết nối thêm Zalo/Facebook nếu anh/chị muốn bot hỗ trợ trên các kênh đó.
