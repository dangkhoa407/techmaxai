# Checklist Nhập Dữ Liệu Vào Phòng Đào Tạo

## Mục Thông tin cơ bản

Copy từ file:
- `01-thong-tin-co-ban.md`

Nên nhập:
- Tên bot: TechMax AI Assistant.
- Vai trò: Bot tư vấn bán hàng cho TechMax AI.
- Tính cách: thân thiện, chuyên nghiệp, rõ ràng, không nói quá.
- Mô tả khác: website, dịch vụ chính, giới hạn không xác nhận thanh toán.

## Mục Train chi tiết

Nên copy theo thứ tự:
1. `07-tai-lieu-train-chi-tiet.md`
2. `02-kien-thuc-dich-vu.md`
3. `03-ky-nang-tu-van.md`
4. `04-kich-ban-hoi-thoai.md`
5. `05-faq.md`
6. `06-quy-dinh-hoat-dong.md`
7. `08-du-lieu-chong-tra-loi-sai.md`

## Nếu phòng đào tạo chia thành nhiều ô

### Kiến thức

Dùng:
- `02-kien-thuc-dich-vu.md`
- Phần "Kiến thức cần nắm" trong `07-tai-lieu-train-chi-tiet.md`

### Kỹ năng tư vấn

Dùng:
- `03-ky-nang-tu-van.md`
- Phần "Quy trình tư vấn bắt buộc" trong `07-tai-lieu-train-chi-tiet.md`

### Tài liệu đào tạo

Dùng:
- `04-kich-ban-hoi-thoai.md`
- `05-faq.md`

### Quy định hoạt động

Dùng:
- `06-quy-dinh-hoat-dong.md`
- `08-du-lieu-chong-tra-loi-sai.md`

## Checklist test bot sau khi train

Hỏi bot các câu sau:

1. "TechMax AI là gì?"
2. "Tôi muốn tạo bot AI tư vấn khách thì làm sao?"
3. "Có dùng được cho Zalo không?"
4. "Auto Facebook làm được gì?"
5. "Proxy dùng để làm gì?"
6. "Tôi muốn nạp tiền thì làm sao?"
7. "Tôi chuyển khoản rồi, kiểm tra giúp tôi."
8. "Có đảm bảo Auto Facebook không checkpoint không?"
9. "Bot có thay nhân viên hoàn toàn không?"
10. "Có cần kết nối API không?"

Kết quả mong muốn:
- Bot trả lời đúng dịch vụ.
- Bot không xác nhận thanh toán.
- Bot không cam kết kết quả 100%.
- Bot hỏi thêm nhu cầu khi cần.
- Bot hướng khách về https://techmaxai.store.
