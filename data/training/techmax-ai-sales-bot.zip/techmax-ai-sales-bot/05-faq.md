# FAQ Cho Bot TechMax AI

## TechMax AI là gì?

TechMax AI là nền tảng hỗ trợ tạo chatbot AI, quản lý hội thoại, kết nối Zalo/Facebook, Auto Facebook, proxy, nạp tiền, hóa đơn và gói dịch vụ. Website: https://techmaxai.store.

## Ai nên dùng TechMax AI?

Phù hợp với shop online, cá nhân kinh doanh, doanh nghiệp nhỏ, đội sale, agency, đơn vị dịch vụ, trung tâm đào tạo hoặc bất kỳ đơn vị nào cần tự động hóa tư vấn và chăm sóc khách hàng.

## Chatbot AI làm được gì?

Chatbot AI có thể trả lời câu hỏi, giới thiệu sản phẩm/dịch vụ, hỏi nhu cầu, tư vấn giải pháp, giải thích chính sách và hướng khách đến bước mua hàng.

## Bot AI có học theo dữ liệu riêng không?

Có. Người dùng có thể đưa thông tin doanh nghiệp, sản phẩm, dịch vụ, bảng giá, chính sách, FAQ và quy trình tư vấn vào phòng đào tạo.

## Có cần biết lập trình không?

Không bắt buộc. Nếu chỉ dùng bot tư vấn theo dữ liệu có sẵn, người dùng có thể nhập nội dung đào tạo trực tiếp. Kết nối API chỉ cần khi có nhu cầu nâng cao.

## Có dùng được cho Zalo không?

Có. TechMax AI hỗ trợ kết nối tài khoản Zalo bằng QR và có thể bật bot AI cho tài khoản Zalo đã kết nối.

## Có dùng được cho Facebook/Fanpage không?

Có. Hệ thống có các phần liên quan Facebook/Fanpage và Auto Facebook. Tùy nhu cầu chăm sóc khách hay automation marketing, bot sẽ tư vấn tính năng phù hợp.

## Auto Facebook có những tác vụ nào?

Auto Facebook hỗ trợ reaction, comment, join group, comment group, đăng bài group, chọn tài khoản chạy, gắn proxy, check proxy và xem log realtime.

## Auto Facebook có đảm bảo không checkpoint không?

Không. Auto Facebook phụ thuộc vào Facebook, cookie, proxy, nội dung và hành vi sử dụng. Bot không được cam kết tránh checkpoint hoặc an toàn 100%.

## Proxy dùng để làm gì?

Proxy giúp tài khoản chạy qua IP riêng, thường dùng cho Zalo và Auto Facebook. Hệ thống có phần thêm proxy, kiểm tra proxy và gắn proxy cho tài khoản.

## Tôi muốn nạp tiền thì làm sao?

Đăng nhập website, vào mục Nạp tiền, nhập số tiền, tạo hóa đơn và chuyển khoản đúng nội dung hệ thống cung cấp. Sau đó xem trạng thái trong mục Hóa đơn.

## Hóa đơn có hết hạn không?

Có. Hóa đơn nạp tiền có thời hạn. Nếu quá hạn mà chưa ghi nhận thanh toán, hóa đơn sẽ chuyển sang trạng thái đã hết hạn và người dùng nên tạo hóa đơn mới.

## Tôi chuyển khoản rồi nhưng chưa thấy cộng tiền?

Hãy kiểm tra đã chuyển đúng số tiền và đúng nội dung hóa đơn chưa. Nếu đúng nhưng vẫn chưa ghi nhận, liên hệ nhân viên hỗ trợ để kiểm tra giao dịch.

## Bot có thể xác nhận thanh toán không?

Không. Bot không xác nhận thanh toán, không cộng tiền và không duyệt hóa đơn. Bot chỉ hướng dẫn người dùng kiểm tra trạng thái hóa đơn trên website.

## Gói dịch vụ là gì?

Gói dịch vụ quyết định quyền sử dụng một số tính năng của hệ thống. Nếu gói hết hạn, một số tính năng có thể bị giới hạn.

## Tôi muốn mua gói dịch vụ thì làm sao?

Nạp tiền vào tài khoản, sau đó vào trang gói dịch vụ để mua hoặc gia hạn gói phù hợp.

## Bot có thay nhân viên được không?

Bot có thể hỗ trợ các câu hỏi lặp lại và tư vấn ban đầu. Với tình huống phức tạp, khiếu nại, thanh toán hoặc cần đàm phán, nên chuyển nhân viên.

## Bot có tự động chốt đơn không?

Bot có thể hỗ trợ hỏi nhu cầu, tư vấn và hướng khách đến bước mua hàng. Việc chốt đơn thành công còn phụ thuộc sản phẩm, giá, niềm tin, chính sách và cách vận hành.

## Khách cần hỗ trợ kỹ thuật thì bot làm gì?

Bot hỏi rõ lỗi, tính năng đang dùng, ảnh chụp/màn hình nếu có. Nếu lỗi cần kiểm tra hệ thống, bot chuyển nhân viên kỹ thuật.
